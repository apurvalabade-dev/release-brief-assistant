import type pg from "pg";
import { hashOf } from "./hash.js";
import type { NormalizedPackage } from "./schema.js";

export interface ReleaseRow {
  id: number;
  name: string;
  createdAt: string;
  latestVersion: number;
}
export interface VersionRow {
  releaseId: number;
  versionNo: number;
  package: NormalizedPackage;
  packageHash: string;
  createdAt: string;
}
export interface VersionSummary {
  versionNo: number;
  packageHash: string;
  createdAt: string;
}

const toVersion = (r: any): VersionRow => ({
  releaseId: r.release_id,
  versionNo: r.version_no,
  package: r.package,
  packageHash: r.package_hash,
  createdAt: new Date(r.created_at).toISOString(),
});

async function inTransaction<T>(pool: pg.Pool, fn: (c: pg.PoolClient) => Promise<T>): Promise<T> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const result = await fn(client);
    await client.query("COMMIT");
    return result;
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
}

async function audit(c: pg.PoolClient, releaseId: number, versionId: number, action: string, detail: unknown) {
  // version_id FK is on release_versions.id; detail carries the human-readable release/version numbers.
  await c.query("INSERT INTO audit_log (version_id, actor, action, detail) VALUES ($1, 'human', $2, $3)", [versionId, action, JSON.stringify({ releaseId, ...(detail as object) })]);
}

export async function createRelease(pool: pg.Pool, name: string, pkg: NormalizedPackage): Promise<{ release: { id: number; name: string }; version: VersionRow }> {
  return inTransaction(pool, async (c) => {
    const rel = await c.query("INSERT INTO releases (name) VALUES ($1) RETURNING id, name", [name]);
    const hash = hashOf(pkg);
    const v = await c.query(
      "INSERT INTO release_versions (release_id, version_no, package, package_hash) VALUES ($1, 1, $2, $3) RETURNING id, release_id, version_no, package, package_hash, created_at",
      [rel.rows[0].id, JSON.stringify(pkg), hash],
    );
    await audit(c, rel.rows[0].id, v.rows[0].id, "release_created", { versionNo: 1 });
    return { release: rel.rows[0], version: toVersion(v.rows[0]) };
  });
}

/**
 * Appends a new immutable version. If the package is identical to the latest version
 * nothing is written (created = false). The release row is locked so concurrent
 * saves get distinct, gapless version numbers.
 */
export async function addVersion(pool: pg.Pool, releaseId: number, pkg: NormalizedPackage): Promise<{ created: boolean; version: VersionRow } | null> {
  return inTransaction(pool, async (c) => {
    const locked = await c.query("SELECT id FROM releases WHERE id = $1 FOR UPDATE", [releaseId]);
    if (locked.rowCount === 0) return null;
    const latest = await c.query("SELECT id, release_id, version_no, package, package_hash, created_at FROM release_versions WHERE release_id = $1 ORDER BY version_no DESC LIMIT 1", [releaseId]);
    const hash = hashOf(pkg);
    if (latest.rows[0]?.package_hash === hash) return { created: false, version: toVersion(latest.rows[0]) };
    const next = (latest.rows[0]?.version_no ?? 0) + 1;
    const v = await c.query(
      "INSERT INTO release_versions (release_id, version_no, package, package_hash) VALUES ($1, $2, $3, $4) RETURNING id, release_id, version_no, package, package_hash, created_at",
      [releaseId, next, JSON.stringify(pkg), hash],
    );
    await audit(c, releaseId, v.rows[0].id, "version_created", { versionNo: next });
    return { created: true, version: toVersion(v.rows[0]) };
  });
}

export async function listReleases(pool: pg.Pool): Promise<ReleaseRow[]> {
  const r = await pool.query(
    `SELECT r.id, r.name, r.created_at, COALESCE(MAX(v.version_no), 0) AS latest
       FROM releases r LEFT JOIN release_versions v ON v.release_id = r.id
      GROUP BY r.id ORDER BY r.created_at DESC, r.id DESC`,
  );
  return r.rows.map((x) => ({ id: x.id, name: x.name, createdAt: new Date(x.created_at).toISOString(), latestVersion: Number(x.latest) }));
}

export async function getRelease(pool: pg.Pool, id: number): Promise<{ id: number; name: string; createdAt: string; versions: VersionSummary[] } | null> {
  const r = await pool.query("SELECT id, name, created_at FROM releases WHERE id = $1", [id]);
  if (r.rowCount === 0) return null;
  const v = await pool.query("SELECT version_no, package_hash, created_at FROM release_versions WHERE release_id = $1 ORDER BY version_no", [id]);
  return {
    id: r.rows[0].id,
    name: r.rows[0].name,
    createdAt: new Date(r.rows[0].created_at).toISOString(),
    versions: v.rows.map((x) => ({ versionNo: x.version_no, packageHash: x.package_hash, createdAt: new Date(x.created_at).toISOString() })),
  };
}

export async function getVersion(pool: pg.Pool, releaseId: number, versionNo: number): Promise<VersionRow | null> {
  const r = await pool.query("SELECT release_id, version_no, package, package_hash, created_at FROM release_versions WHERE release_id = $1 AND version_no = $2", [releaseId, versionNo]);
  return r.rows[0] ? toVersion(r.rows[0]) : null;
}
