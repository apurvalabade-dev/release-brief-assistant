import { Router, type NextFunction, type Request, type Response } from "express";
import type pg from "pg";
import { z } from "zod";
import { runDeterministicChecks } from "../checks.js";
import { diffPackages } from "../diff.js";
import { parsePackage } from "../schema.js";
import * as repo from "../repo.js";

const wrap = (fn: (req: Request, res: Response) => Promise<void>) => (req: Request, res: Response, next: NextFunction) => {
  fn(req, res).catch(next);
};

const id = z.coerce.number().int().positive();
const createBody = z.object({ name: z.string().trim().min(1).max(200), package: z.unknown() });
const versionBody = z.object({ package: z.unknown() });
const diffQuery = z.object({ from: id, to: id });

const notFound = (res: Response, what: string) => void res.status(404).json({ error: "not_found", what });

export function releaseRoutes(pool: pg.Pool): Router {
  const router = Router();

  router.post("/", wrap(async (req, res) => {
    const body = createBody.parse(req.body);
    const pkg = parsePackage(body.package ?? {});
    const created = await repo.createRelease(pool, body.name, pkg);
    res.status(201).json({ ...created, checks: runDeterministicChecks(pkg) });
  }));

  router.get("/", wrap(async (_req, res) => {
    res.json({ releases: await repo.listReleases(pool) });
  }));

  router.get("/:id", wrap(async (req, res) => {
    const release = await repo.getRelease(pool, id.parse(req.params["id"]));
    if (!release) return notFound(res, "release");
    res.json(release);
  }));

  router.post("/:id/versions", wrap(async (req, res) => {
    const releaseId = id.parse(req.params["id"]);
    const pkg = parsePackage(versionBody.parse(req.body).package ?? {});
    const result = await repo.addVersion(pool, releaseId, pkg);
    if (!result) return notFound(res, "release");
    res.status(result.created ? 201 : 200).json({ ...result, checks: runDeterministicChecks(result.version.package) });
  }));

  // Registered before "/:id/versions/:n" so "diff" is never read as a version number.
  router.get("/:id/diff", wrap(async (req, res) => {
    const releaseId = id.parse(req.params["id"]);
    const q = diffQuery.parse(req.query);
    const [a, b] = await Promise.all([repo.getVersion(pool, releaseId, q.from), repo.getVersion(pool, releaseId, q.to)]);
    if (!a || !b) return notFound(res, "version");
    res.json({ releaseId, from: q.from, to: q.to, diff: diffPackages(a.package, b.package) });
  }));

  router.get("/:id/versions/:n", wrap(async (req, res) => {
    const version = await repo.getVersion(pool, id.parse(req.params["id"]), id.parse(req.params["n"]));
    if (!version) return notFound(res, "version");
    res.json({ version, checks: runDeterministicChecks(version.package) });
  }));

  return router;
}
